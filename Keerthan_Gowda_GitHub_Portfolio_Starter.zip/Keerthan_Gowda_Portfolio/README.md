# Keerthan Gowda – Portfolio

Welcome to my professional portfolio. I am a Technical Writer and Content Specialist with experience in digital publishing, SEO-focused content creation, and structured documentation.

## 📘 About Me
- 🧠 Background: Aeronautical Engineering (Dayananda Sagar College of Engineering)
- ✍️ Focus: Technical documentation, web content, structured authoring
- 🛠 Tools: AEM, WordPress, ChatGPT, Markdown, Canva, Draw.io
- 🔗 Contact: keerthangowda26@gmail.com | [LinkedIn](#)

---

## 📂 Portfolio Projects

### 1. Landing Pages – TTI/Mouser Electronics
Created and maintained over 150+ product landing pages using AEM and CMS systems. Ensured brand compliance, optimized layout, and clear product messaging.

### 2. Educational Content – Think & Learn Pvt. Ltd.
Structured curriculum-aligned modules and designed visual assessments. Created clear learning journeys and assessment tools.

### 3. Documentation Samples
See the `/writing-samples/` folder for examples of SOPs, product documentation, and content QA reports.

---

## 📜 Certifications
- SEO & Content Strategy – Coursera
- Advanced Technical Writing – Coursera (In Progress)
- Copywriting for Digital Marketing – Udemy

---

Thanks for visiting! For more, feel free to explore each folder or reach out for collaboration.
