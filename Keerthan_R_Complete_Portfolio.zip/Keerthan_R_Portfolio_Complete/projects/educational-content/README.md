# 🎓 Educational Content – Think & Learn Pvt. Ltd.

## 🖋 Role: Faculty Content Specialist
- Created structured modules and assessments for online learning
- Designed scripts, quizzes, and visual lessons for students
- Simplified complex concepts for digital learning platforms

## 🛠 Tools Used
Google Docs · Canva · Draw.io · PowerPoint

## 🧠 Outcome
Improved learning engagement and delivery quality through modular content.
