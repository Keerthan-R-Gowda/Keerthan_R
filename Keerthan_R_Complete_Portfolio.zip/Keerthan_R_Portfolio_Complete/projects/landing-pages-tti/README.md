# 🧩 Landing Pages – TTI / Mouser Electronics

## 🔧 Role: Content Specialist
- Built and maintained over 150+ landing pages using AEM and CMS platforms
- Focused on product visibility, layout consistency, and SEO
- Collaborated with design, marketing, and supplier teams

## 📎 Tools
- AEM · HTML · Excel · Grammarly · Adobe Photoshop

## 📈 Impact
Improved engagement and discoverability across supplier campaigns.
