# 📜 Certifications

This folder contains digital copies and lists of all certifications completed and in progress.