# 🖼 Visual Communication Samples

This folder contains sample visual work created using Canva, Draw.io, and PowerPoint.

- Infographics
- Flowcharts
- Slide mockups

*Note: Visuals are for illustrative purposes only.*
